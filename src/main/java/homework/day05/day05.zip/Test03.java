package homework.day05;

import java.io.*;

public class Test03 {
    public static void main(String[] args) throws IOException {
        File dir = new File(".");
        if(dir.isDirectory()){
            File[] subs = dir.listFiles(f->f.getName().endsWith(".txt"));
            for(File sub : subs){
                System.out.println(sub.getName());
                String n = sub.getName().substring(0,sub.getName().indexOf("."));
                System.out.println(n);
                String m = sub.getName().substring(sub.getName().indexOf(".")+1);
                System.out.println(m);
                FileInputStream fis = new FileInputStream(sub.getName());
                FileOutputStream fos = new FileOutputStream(n+"_cp."+m);
                byte[] data = new byte[1024];
                int l = 0;
                long start = System.currentTimeMillis();
                while ((l=fis.read(data))!=-1) {
                    fos.write(data, 0, l);
                }
                    long end = System.currentTimeMillis();
                    System.out.println("复制完成！耗时"+(end-start));
                    fis.close();
                    fos.close();


            }
        }


    }
}
