package homeworkday02;

import java.util.Arrays;

public class Test01 {
    public static void main(String[] args) {
        m1();
        m2();
    }
    public static void m1(){
        String path = "http://localhost:8088/myweb/reg?name=zhangsan";
        /*
         * 将上述字符串按照"?"拆分为两部分并输出
         * ?左侧在控制台输出内容为:
         * 请求:http://localhost:8088/myweb/reg
         *
         * ?右侧在控制台输出内容为:
         * 参数:name=zhangsan
         *
         */
        //按照？号拆分成两个数组
        String[] str = path.split("\\?");
        //分别输出两个数组
        System.out.println("请求："+str[0]);
        System.out.println("参数："+str[1]);
    }
    public static void m2(){
        /*
         * 进一步练习:
         */
        //           请求部分                                     ?                 参数部分
        String path = "http://localhost:8088/myweb/reg?name=zhangsan&pwd=123456&nick=san&age=16";
        /*
         * 先拆分出请求部分与参数部分
         *
         * 观察参数部分的格式，找出规律后再将每一个参数的名字和值
         * 得到并输出为:
         * 参数名:name,参数值:zhangsan
         * 参数名:pwd,参数值:123456
         * ...
         */
        //拆分出请求部分与参数部分
        String[] data = path.split("\\?");
        //输出请求部分内容
        System.out.println("请求："+data[0]);
        //拆分参数部分“&”
        String[] paras = data[1].split("&");
        //循环遍历数组paras
        for (int i = 0; i < paras.length; i++) {
            String[] para = paras[i].split("=");//分别拆分paras数组每一个字符串用=号
            System.out.println("参数名："+para[0]+",参数值："+para[1]);//输出
        }




    }
}
