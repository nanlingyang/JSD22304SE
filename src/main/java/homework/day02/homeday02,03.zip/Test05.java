package homeworkday02;

import java.util.Scanner;

public class Test05 {
    public static void main(String[] args) {
        //初始化成员变量
        String name;
        String age;
        //导入键盘
        Scanner sca = new Scanner(System.in);
        //提示用户输出
        System.out.println("请输入你的名字...");
        //接收用户输出
        name = sca.nextLine();
        //正则表达式2
        String regex = "(^\\w{3,15}$)";
        String regex1 = "([1-9]|[1-9][0-9]|100)";
        //判断
        boolean match = name.matches(regex);
        if(match){
            System.out.println("输入正确......");
        }else{
            System.out.println("输入错误...");
        }
        System.out.println("请输入你的年龄...");
        age = sca.nextLine();
        boolean match1 = age.matches(regex1);
        if(match1){
            System.out.println("输入正确......");
        }else {
            System.out.println("输入错误...");
        }
        int num  = Integer.parseInt(age);
        if(num<=100 && num>=0){
            System.out.println("正确");
        }
    }
}