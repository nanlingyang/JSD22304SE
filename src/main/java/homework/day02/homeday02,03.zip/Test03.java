package homeworkday02;
/**
 * 执行程序，分析并解决问题
 * NumberFormatException出现的情况通常是由包装类将字符串解析为基本类型时,由于字符串内容不能正确描述基本类型导致该异常.
 * 数字    格式      异常
 *
 */
public class Test03 {
    public static void main(String[] args) {
        /*
         * 原因:字符串末尾有空格，把空格去掉用trim()
         */
        String num = "123 ";
        String noSpaceStr = num.trim();
        int d =Integer.parseInt(noSpaceStr);
        System.out.println(d);

        /*
         * 原因:类型不匹配应该用double类型引用
         */
        num = "123.456";
        double d1 = Double.parseDouble(num);
        System.out.println(d1);

        /*
         * 原因:
         */
//		num = "123";
//		d = Integer.parseInt(num)；
//		System.out.println(d);
    }
}
