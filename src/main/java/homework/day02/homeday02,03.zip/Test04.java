package homeworkday02;

import java.util.Scanner;

public class Test04 {
    public static void main(String[] args) {
        Person p = new Person();
        Scanner scan = new Scanner(System.in);//为导入获取输出包，区分大小写
        System.out.println("请输入用户名");
        String name = scan.nextLine();
        if(name.length()==0){//此时P对象为空，不能通过其调用方法
            System.out.println("姓名不能为空!");
        }else {
            p.setName(name);
        }
        System.out.println("请输入年龄:");
        int age = scan.nextInt();
        if(p.getAge()<0&&p.getAge()>100){
            System.out.println("年龄不合法!");
        }else {
            p.setAge(age);//对象打点set
        }
        System.out.println("姓名："+p.getName());//对象打点get
        System.out.println("年龄："+p.getAge());

    }
}

class Person{
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
