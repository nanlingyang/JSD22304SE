package homework.day01;

public class Test04 {
    public static void main(String[] args) {
        String fileName = "123.png";

        boolean check = fileName.endsWith(".png");
        System.out.println(check?"是":"不是");
    }
}
