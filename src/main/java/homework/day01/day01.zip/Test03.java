package homework.day01;

public class Test03 {
    public static void main(String[] args) {
        String str = "hello world! i love java!";
        for (int i = 0; i <str.length(); i++) {
            char c = str.charAt(i);
            System.out.print(c);
        }
    }


}
